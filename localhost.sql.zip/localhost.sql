-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 01 月 31 日 16:34
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `studay`
--
CREATE DATABASE `studay` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `studay`;

-- --------------------------------------------------------

--
-- 表的结构 `praise`
--

CREATE TABLE IF NOT EXISTS `praise` (
  `id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `praiseNum` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='点赞表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `praise`
--

INSERT INTO `praise` (`id`, `praiseNum`) VALUES
(1, 201);
